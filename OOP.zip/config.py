TOKEN = "6082197597:AAE9cfdatOLAmIS8T32yc0SCoRBrks23uPk"
keys = {
    'доллар': 'USD',
    'евро': 'EUR',
    'рубль': 'RUB'
}
